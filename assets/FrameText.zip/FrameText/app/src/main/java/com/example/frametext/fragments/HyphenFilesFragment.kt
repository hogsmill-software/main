package com.example.frametext.fragments

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.frametext.HyphenDetails
import com.example.frametext.R
import com.example.frametext.adapters.HyphenDetailsListAdapter
import com.example.frametext.databinding.FragmentHyphenFilesBinding
import com.example.frametext.viewModels.HyphenDetailsListViewModel
import com.example.frametext.viewModels.HyphenFilesListViewModel

class HyphenFilesFragment : Fragment() {
    private var hyphenDetailsList: ArrayList<HyphenDetails>? = null
    private var hyphenFileDetailsList: androidx.recyclerview.widget.RecyclerView? = null
    private var hyphenFilesList: ArrayList<String>? = null
    private var fragmentActivityContext: FragmentActivity? = null
    private var hyphenDetailsListAdapter: HyphenDetailsListAdapter? = null
    private var binding: FragmentHyphenFilesBinding? = null


    private lateinit var linearLayoutManager: LinearLayoutManager


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHyphenFilesBinding.inflate(layoutInflater)
        container?.removeAllViews()

        // Inflate the layout for this fragment
        val view =  inflater.inflate(R.layout.fragment_hyphen_files, container, false)
     //   val view = binding!!.root

        val button = view.findViewById<View>(R.id.backButton)
        button.setOnClickListener { navigateToSettingsFragment() }

        linearLayoutManager = LinearLayoutManager(context)

        hyphenFilesRecyclerView.layoutManager = linearLayoutManager

        return view
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        fragmentActivityContext = context as FragmentActivity
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val hyphenDetailsListViewModel: HyphenDetailsListViewModel =
            ViewModelProvider(requireActivity()).get(
                HyphenDetailsListViewModel::class.java
            )
        hyphenDetailsList = hyphenDetailsListViewModel.selectedItem.value
        val hyphenFilesListViewModel: HyphenFilesListViewModel =
            ViewModelProvider(requireActivity()).get(
                HyphenFilesListViewModel::class.java
            )
        hyphenFilesList = hyphenFilesListViewModel.selectedItem.value
        hyphenFileDetailsList = view.findViewById(R.id.hyphenFileListView)

        // set the adapter to fill the data in the ListView
 /*       if (hyphenDetailsList != null) {
            val hd: Array<HyphenDetails> = hyphenDetailsList!!.toArray(arrayOfNulls(0))
            val hyphenDetailsListAdapter = hyphenFilesList?.let { HyphenDetailsListAdapter(view.context, hd, it) }
            hyphenFileDetailsList?.adapter = hyphenDetailsListAdapter
        } */

    //    val app = activity

       // if (app != null){
        if (hyphenDetailsList != null) {
            val hd: Array<HyphenDetails> = hyphenDetailsList!!.toArray(arrayOfNulls(0))
        //    val hyphenDetailsListAdapter = hyphenFilesList?.let { HyphenDetailsListAdapter(view.context, hd, it) }
         //   hyphenFileDetailsList?.adapter = hyphenDetailsListAdapter
            hyphenDetailsListAdapter = hyphenFilesList?.let {
                HyphenDetailsListAdapter(
                    view.context, hd, it, this
                )
            }
            binding!!.hyphenFileListView.adapter = hyphenDetailsListAdapter

        }


         //   binding!!.inAppInventory.adapter = newFeatureListAdapter
    }

    private fun navigateToSettingsFragment() {
        fragmentActivityContext?.supportFragmentManager?.beginTransaction()
            ?.replace(R.id.settings_frame, SettingsFragment())
            ?.setReorderingAllowed(true)
            ?.commit()
    }
}