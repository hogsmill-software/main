package com.example.frametext.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import androidx.appcompat.widget.AppCompatButton
import com.example.frametext.MainActivity
import com.example.frametext.R
import com.example.frametext.fragments.UserFilesFragment
import com.example.frametext.viewModels.TextInputViewModel
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.io.IOException

class UserFileListAdapter internal constructor(
    context: Context,
    userFileList: ArrayList<String>?,
    textInputViewModel: TextInputViewModel,
    userFile: UserFilesFragment
) :
    BaseAdapter() {
    var userFilesInflater: LayoutInflater
    var userFileList: ArrayList<String>?
    private val textInputViewModel: TextInputViewModel
    var context: Context
    var userFile: UserFilesFragment
    override fun getCount(): Int {
        return if (userFileList != null) userFileList!!.size else 0
    }

    override fun getItem(i: Int): Any {
        return userFileList!![i]
    }

    override fun getItemId(i: Int): Long {
        return i.toLong()
    }

    override fun getView(i: Int, view: View, viewGroup: ViewGroup): View {
        var view: View
        view = userFilesInflater.inflate(R.layout.list_user_files_items, null)
        val userFileNameView = view.findViewById<TextView>(R.id.fileName)
        userFileNameView.text = userFileList!![i]
        val loadButton = view.findViewById<AppCompatButton>(R.id.loadButton)
        loadButton.setOnClickListener { v: View? ->
            loadFile(
                i
            )
        }
        val deleteButton = view.findViewById<AppCompatButton>(R.id.deleteButton)
        deleteButton.setOnClickListener { v: View? ->
            deleteFile(
                i
            )
        }
        return view
    }

    fun loadFile(i: Int) {
        val userFileFolder: String? = MainActivity.getUserFileFolder(true, context)
        if (userFileFolder != null) {
            val usrFile = File(userFileFolder + userFileList!![i])
            if (usrFile.exists()) {
                val fileContentBuilder = StringBuilder()
                try {
                    BufferedReader(FileReader(usrFile)).use { br ->
                        var currentLine: String?
                        while (br.readLine().also { currentLine = it } != null) {
                            fileContentBuilder.append(currentLine).append("\n")
                        }
                    }
                } catch (e: IOException) {
                    e.printStackTrace()
                }
                val fileContent = fileContentBuilder.toString()
                textInputViewModel.selectItem(fileContent)
                userFile.setToTextInputFragment()
            }
        }
    }

    fun deleteFile(i: Int) {
        val userFileFolder: String? = MainActivity.getUserFileFolder(true, context)
        if (userFileFolder != null) {
            val usrFile = File(userFileFolder + userFileList!![i])
            if (usrFile.exists()) {
                if (usrFile.delete()) {
                    userFileList!!.removeAt(i)
                    notifyDataSetChanged()
                }
            }
        }
    }

    init {
        userFilesInflater = LayoutInflater.from(context)
        this.context = context
        this.userFileList = userFileList
        this.textInputViewModel = textInputViewModel
        this.userFile = userFile
    }
}
