package com.example.frametext.fragments

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.example.frametext.R

class UserFilesFragment : Fragment() {
    private var fragmentActivityContext: FragmentActivity? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        container?.removeAllViews()
        val view =  inflater.inflate(R.layout.fragment_user_files, container, false)

        val backButton = view.findViewById<View>(R.id.backButton)
        backButton.setOnClickListener { setToTextInputFragment() }

        return view
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        fragmentActivityContext = context as FragmentActivity
    }

    fun setToTextInputFragment() {
        fragmentActivityContext?.supportFragmentManager?.beginTransaction()
            ?.replace(R.id.text_input_frame, TextInputFragment())
            ?.setReorderingAllowed(true)
            ?.commit()
    }
}