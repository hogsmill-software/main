package com.example.frametext

class FrameTextParameters {
    var hyphenFileName: String? = null
    var optimizeSpacing = true
    var hyphenateText = false
    private var txtSymbolsMargin = 20
    private val maxTxtSymbolsMargin = 50
    var outerMargin = 15
    var textColor = -0x1000000
    var symbolsColor = -0x10000
    var backgroundColor = -0x1
    var useEmoji = false
    var emoji = Character.toString(0x2665.toChar())
    var symbolShapeType: SymbolShapeType = SymbolShapeType.Heart
    var mainShapeType: MainShapeType = MainShapeType.Heart
    var symbol: String? = "☻"

    fun setTxtSymbolsMargin(txtSymbolsMargin: Int) {
        if (txtSymbolsMargin <= maxTxtSymbolsMargin) this.txtSymbolsMargin = txtSymbolsMargin
    }

    fun getTxtSymbolsMargin(): Int {
        return txtSymbolsMargin
    }

   /* fun getShapeDetails(): ShapeDetails? {
        if (useEmoji) {
            return EmojiShapeDetails(emoji)
        } else if (symbol != null && shapeType === ShapeType.None) {
            return SymbolShapeDetails(symbol, heartsColor)
        }
        when (shapeType) {
            StraightHeart -> return DrawHeartDetails(heartsColor, 92)
            Circle -> return DrawCircleDetails(heartsColor, 92)
            Square -> return DrawSquareDetails(heartsColor, 92)
            Star -> return DrawStarDetails(heartsColor, 92)
            Spade -> return DrawSpadeDetails(heartsColor, 92)
            Club -> return DrawClubDetails(heartsColor, 92)
            Diamond -> return DrawDiamondDetails(heartsColor, 92)
            Smiley -> return DrawSmileyDetails(heartsColor, 92)
        }
        return null
    }
*/
}