package com.example.frametext.fragments

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.example.frametext.R

class SettingsFragment : Fragment() {
    private var fragmentActivityContext: FragmentActivity? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        container?.removeAllViews()
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_settings, container, false)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        fragmentActivityContext = context as FragmentActivity
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?)
    {

        val button = view.findViewById<View>(R.id.downloadHyphenNavButton)
        button.setOnClickListener { navigateToHyphenationFragment() }

    }

    fun saveSelectedItem() {
   //     selectedItem = spinner.getSelectedItem() as String
   //     neededToDownloadText = hyphenFilesList.isEmpty()
    }

    fun updateHyphenDropdown() {
    /*    if (hyphenFilesList.isEmpty()) {
            needToDownloadText.setVisibility(View.VISIBLE)
            spinner.setVisibility(View.GONE)
            hyphenateSwitch.setVisibility(View.GONE)
            wasHyphenFileListEmpty = true
        } else {
            needToDownloadText.setVisibility(View.GONE)
            spinner.setVisibility(View.VISIBLE)
            hyphenateSwitch.setVisibility(View.VISIBLE)
            val context = this.context

            // If the hyphenFile list was empty and has just been filled, we switch hyphenation on.
            if (wasHyphenFileListEmpty) {
                hyphenateSwitch.setChecked(true)
            }
            wasHyphenFileListEmpty = false
            if (context != null) {
                val arrayAdapter: ArrayAdapter<String> = ArrayAdapter<String>(
                    context,
                    R.layout.spinner_list, hyphenFilesList
                )
                arrayAdapter.setDropDownViewResource(R.layout.spinner_list)
                spinner.setAdapter(arrayAdapter)
            }
            if (selectedItem != null && hyphenFilesList.contains(selectedItem)) {
                val pos: Int = hyphenFilesList.indexOf(selectedItem)
                spinner.setSelection(pos)
            }
            if (neededToDownloadText) {
                hyphenateSwitch.setChecked(true)
            }
        } */
    }

    private fun navigateToHyphenationFragment() {
        val fragment: Fragment = HyphenFilesFragment()
        val fragmentManager = fragmentActivityContext!!.supportFragmentManager
        fragmentManager.beginTransaction()
            .replace(R.id.settings_frame, fragment)
            .setReorderingAllowed(true)
            .addToBackStack(null)
            .commit()
    }
}