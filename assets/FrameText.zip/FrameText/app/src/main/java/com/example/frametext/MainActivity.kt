package com.example.frametext

import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback
import com.example.frametext.adapters.FrameTextAdapter
import com.example.frametext.viewModels.HyphenDetailsListViewModel
import com.example.frametext.viewModels.HyphenFilesListViewModel
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.io.IOException
import java.nio.charset.StandardCharsets

class MainActivity : AppCompatActivity() {
    private var tabLayout: TabLayout? = null
    private var viewPager: ViewPager2? = null
    private val hyphenDetailsList = ArrayList<HyphenDetails>()
    private val hyphenFilesList = ArrayList<String>()
    private var tabSetting: TabLayout.Tab? = null
    private var hplFileNameMap = HashMap<String, String>()
    private var fileNameHplMap = HashMap<String, String>()
    private var hvp: FrameTextParameters = FrameTextParameters()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        try {
            val hyphenDetailsArray = JSONArray(loadJSONFromAsset())
            var hyphenFileSet = false
            for (idx in 0 until hyphenDetailsArray.length()) {
                val hyphenDetail: JSONObject = hyphenDetailsArray.getJSONObject(idx)
                val hd = HyphenDetails(
                    hyphenDetail.getInt("id"),
                    hyphenDetail.getString("hpl"),
                    hyphenDetail.getBoolean("downLoaded"),
                    hyphenDetail.getString("fileName"),
                    hyphenDetail.getString("downloadLink")
                )
                val hyphenFileFolder = getHyphenFileFolder(applicationContext)
                if (hyphenFileFolder != null) {
                    val hyphenFile = File(hyphenFileFolder + hyphenDetail.getString("fileName"))
                    if (hyphenFile.exists()) {
                        hd.downLoaded = true
                        hyphenFilesList.add(hyphenDetail.getString("hpl"))
                        hvp.hyphenateText = true
                        if (!hyphenFileSet) {
                            hvp.hyphenFileName = hyphenDetail.getString("fileName")
                            hyphenFileSet = true
                        }
                    }
                }
                hyphenDetailsList.add(hd)
                hplFileNameMap[hyphenDetail.getString("hpl")] = hyphenDetail.getString("fileName")
                fileNameHplMap[hyphenDetail.getString("fileName")] = hyphenDetail.getString("hpl")
            }
            loadSavedSettings()
        } catch (e: JSONException) {
            e.printStackTrace()
        } catch (e: IOException) {
            e.printStackTrace()
        }


        // Tabs set up below:
        tabLayout = findViewById(R.id.tabLayout)
        viewPager = findViewById(R.id.pager)
        tabLayout?.newTab()?.setText(resources.getString(R.string.text_input))
            ?.let { tabLayout?.addTab(it) }
        tabSetting = tabLayout?.newTab()?.setText(resources.getString(R.string.settings))
        tabSetting?.let { tabLayout?.addTab(it) }
        tabLayout?.newTab()?.setText(resources.getString(R.string.image))
            ?.let { tabLayout?.addTab(it) }
        tabLayout?.tabGravity = TabLayout.GRAVITY_FILL
        val adapter = FrameTextAdapter(this, this, tabLayout?.tabCount ?: 0)
        viewPager?.adapter = adapter

        viewPager?.registerOnPageChangeCallback(object : OnPageChangeCallback() {
            /*override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels)
            }
*/
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                val tab = tabLayout?.getTabAt(position)
                tab?.select()
            }
/*
            override fun onPageScrollStateChanged(state: Int) {
                super.onPageScrollStateChanged(state)
            } */
        })

        tabLayout?.addOnTabSelectedListener(object : OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                if (tab === tabSetting) {
                    adapter.updateHyphenDropdown()
                }
                viewPager?.currentItem = tab.position
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {
                if (tab === tabSetting) {
                    adapter.saveSelectedItem()
                }
            }

            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        //  Hyphen Details List
        val hyphenDetailsListViewModel: HyphenDetailsListViewModel = ViewModelProvider(this).get(
            HyphenDetailsListViewModel::class.java
        )
        hyphenDetailsListViewModel.selectItem(hyphenDetailsList)
        hyphenDetailsListViewModel.selectedItem.observe(this) { }

        // Hyphen file List
        val hyphenFilesListViewModel: HyphenFilesListViewModel = ViewModelProvider(this).get(
            HyphenFilesListViewModel::class.java
        )
        hyphenFilesListViewModel.selectItems(hyphenFilesList)
        hyphenFilesListViewModel.selectedItem.observe(this) { }

    }

    @Throws(IOException::class, JSONException::class)
    private fun loadSavedSettings() {
        val settingsFileName = getSettingsFileName(applicationContext)
        if (settingsFileName != null) {
            val settingsFile = File(settingsFileName)
            if (settingsFile.exists()) {
                val settings: String? = readSavedSettingsFomFile()
                if (settings != null) {
                    val jsonObject = JSONObject(settings)
                    hvp.hyphenFileName = jsonObject["hyphenFileName"] as String
                    hvp.optimizeSpacing = jsonObject.getBoolean("optimizeSpacing")
                    hvp.hyphenateText = jsonObject.getBoolean("hyphenateText")
                    hvp.setTxtSymbolsMargin(jsonObject.getInt("txtSymbolsMargin"))
                    hvp.outerMargin = jsonObject.getInt("outerMargin")
                    hvp.textColor = jsonObject.getInt("textColor")
                    hvp.symbolsColor = jsonObject.getInt("symbolsColor")
                    hvp.backgroundColor = jsonObject.getInt("backgroundColor")
                    hvp.useEmoji = jsonObject.getBoolean("useEmoji")
                    // These values are new so can be legitimately missing from older versions
                    try {
                        val str = jsonObject["emoji"] as String
                        hvp.emoji = str

                        // Added at same time as emoji so if emoji fails, this will too.
                        // Similarly, if emoji passes, this will too.
                        val shapeType = jsonObject["shapeType"] as String
                        hvp.symbolShapeType = SymbolShapeType.valueOf(shapeType)
                        val mainShape = jsonObject["mainShape"] as String
                        hvp.mainShapeType = MainShapeType.valueOf(mainShape)

                        // Added last so if others fail, this will too.
                        val symbol = jsonObject["symbol"] as String
                        hvp.symbol = symbol
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

    @Throws(IOException::class)
    private fun readSavedSettingsFomFile(): String? {
        val settingsFilePath: String? = getSettingsFileName(applicationContext)
        if (settingsFilePath != null) {
            val file = File(settingsFilePath)
            val fileReader = FileReader(file)
            val bufferedReader = BufferedReader(fileReader)
            val stringBuilder = StringBuilder()
            var line = bufferedReader.readLine()
            while (line != null) {
                stringBuilder.append(line).append("\n")
                line = bufferedReader.readLine()
            }
            bufferedReader.close()
            return stringBuilder.toString()
        }
        return null
    }

    private fun loadJSONFromAsset(): String? {
        val json: String = try {
            val `is` = assets.open("hyphenDetails.json")
            val size = `is`.available()
            val buffer = ByteArray(size)
            `is`.read(buffer)
            `is`.close()
            String(buffer, StandardCharsets.UTF_8)
        } catch (ex: IOException) {
            ex.printStackTrace()
            return null
        }
        return json
    }



    companion object {

        @JvmStatic
        fun getSettingsFileName(context: Context): String? {
            var folderCreated = true
            val docDir = context.filesDir
            val heartsValFolder = docDir.path + "/HeartsVal"
            val heartsValDir = File(heartsValFolder)
            if (!heartsValDir.exists()) {
                folderCreated = heartsValDir.mkdir()
            }
            if (folderCreated) {
                val settingsFolder = "$heartsValFolder/Settings"
                val settingsDir = File(settingsFolder)
                if (!settingsDir.exists()) {
                    folderCreated = settingsDir.mkdir()
                }
                return if (folderCreated) "$settingsFolder/settings.json" else null
            }
            return null
        }

        @JvmStatic
        fun getHyphenFileFolder(context: Context): String? {
            var folderCreated = true
            val docDir = context.filesDir
            val heartsValFolder = docDir.path + "/HeartsVal"
            val heartsValDir = File(heartsValFolder)
            if (!heartsValDir.exists()) {
                folderCreated = heartsValDir.mkdir()
            }
            if (folderCreated) {
                val hyphenFileFolder = "$heartsValFolder/Hyphenation"
                val hyphenFileDir = File(hyphenFileFolder)
                if (!hyphenFileDir.exists()) {
                    folderCreated = hyphenFileDir.mkdir()
                }
                return if (folderCreated) "$hyphenFileFolder/" else null
            }
            return null
        }

        @JvmStatic
        fun getUserFileFolder(appendBackslash: Boolean, context: Context): String? {
            var folderCreated = true
            val docDir = context.filesDir
            val heartsValFolder = docDir.path + "/HeartsVal"
            val heartsValDir = File(heartsValFolder)
            if (!heartsValDir.exists()) {
                folderCreated = heartsValDir.mkdir()
            }
            if (folderCreated) {
                val userFileFolder = "$heartsValFolder/UserFiles"
                val userFileDir = File(userFileFolder)
                if (!userFileDir.exists()) {
                    folderCreated = userFileDir.mkdir()
                }
                return if (folderCreated) userFileFolder + (if (appendBackslash) '/' else "") else null
            }
            return null
        }
    }
}