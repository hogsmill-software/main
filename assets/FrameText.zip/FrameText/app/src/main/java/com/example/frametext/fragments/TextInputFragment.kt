package com.example.frametext.fragments

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.example.frametext.R

class TextInputFragment : Fragment() {
    private var fragmentActivityContext: FragmentActivity? = null
 //   private var textInputViewModel: TextInputViewModel? = null

   // private var tabLayoutViewModel: TabLayoutViewModel? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        container?.removeAllViews()
        val view =  inflater.inflate(R.layout.fragment_text_input, container, false)

        val generateImageButton = view.findViewById<View>(R.id.generateImageButton)
        generateImageButton.setOnClickListener { generateImage(view) }

        val loadSaveFileNavButton = view.findViewById<View>(R.id.loadSaveFileNavButton)
        loadSaveFileNavButton.setOnClickListener { onExitToUserFilesFragment(view) }

        return view
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        fragmentActivityContext = context as FragmentActivity
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
  //      textInputViewModel = ViewModelProvider(requireActivity())[TextInputViewModel::class.java]
  //      heartsValBitmapViewModel =
 //           ViewModelProvider(requireActivity()).get(HeartsValBitmapViewModel::class.java)
   //     tabLayoutViewModel = ViewModelProvider(requireActivity())[TabLayoutViewModel::class.java]
    //    heartValParametersViewModel = ViewModelProvider(requireActivity()).get(
     //       HeartValParametersViewModel::class.java
     //   )
  //      val editTextInput = view.findViewById<EditText>(R.id.editTextInput)
   //     editTextInput.setText(textInputViewModel?.getSelectedItem()?.value)
    }

    private fun generateImage(view: View?) {
    }

    private fun onExitToUserFilesFragment(view: View) {
     //   val editTextInput = view.findViewById<EditText>(R.id.editTextInput)
     //   textInputViewModel?.selectItem(editTextInput.text.toString())
        setToUserFilesFragment()
    }

    private fun setToUserFilesFragment() {
        fragmentActivityContext?.supportFragmentManager?.beginTransaction()
            ?.replace(R.id.text_input_frame, UserFilesFragment())
            ?.setReorderingAllowed(true)
            ?.commit()
    }
}