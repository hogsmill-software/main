package com.example.frametext

enum class MainShapeType {
    None,
    Heart,
    Circle,
    Square,
}