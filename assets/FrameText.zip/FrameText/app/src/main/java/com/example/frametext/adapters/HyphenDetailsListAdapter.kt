package com.example.frametext.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.RecyclerView
import com.example.frametext.HyphenDetails
import com.example.frametext.R
import com.example.frametext.databinding.ListHyphenItemsBinding
import com.example.frametext.fragments.HyphenFilesFragment

class HyphenDetailsListAdapter internal constructor(
    context: Context,
    hyphenDetails: Array<HyphenDetails>,
    hyphenFilesList: ArrayList<String>,
    hyphenFilesFragment: HyphenFilesFragment
) : RecyclerView.Adapter<HyphenDetailsListAdapter.ViewHolder>() {
    private var context: Context
    private var hyphenDetails: Array<HyphenDetails>
    private var hyphenFilesList: ArrayList<String>
    private var hyphenFilesFragment: HyphenFilesFragment

    inner class ViewHolder(private val binding: ListHyphenItemsBinding) :
        RecyclerView.ViewHolder(binding.root) {
        var textView: TextView =
            binding.root.rootView.findViewById<View>(R.id.textView) as TextView
        var button: AppCompatButton =
            binding.root.rootView.findViewById<View>(R.id.button) as AppCompatButton

        fun bind(hd: HyphenDetails, hyphenFilesFragment: HyphenFilesFragment) {

            binding.textView.text = hd.hyphenatePatternLanguage
         //   val hd :HyphenDetails
         //   hd.
            binding.lifecycleOwner = hyphenFilesFragment
            binding.executePendingBindings()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = ListHyphenItemsBinding.inflate(layoutInflater, parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(
        holder: HyphenDetailsListAdapter.ViewHolder,
        position: Int
    ) {
      //  holder.bind(hyphenDetails[position], hyphenFilesFragment)

        holder.textView.text = hyphenDetails[position].hyphenatePatternLanguage

    }

    override fun getItemCount(): Int {
        return  hyphenDetails.size
    }

    init {
        this.context = context
        this.hyphenDetails = hyphenDetails
        this.hyphenFilesList = hyphenFilesList
        this.hyphenFilesFragment = hyphenFilesFragment
    }
}